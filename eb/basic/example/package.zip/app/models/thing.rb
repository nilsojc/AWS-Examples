class Thing < ApplicationRecord
end